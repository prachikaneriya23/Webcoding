/* Lightweight JS:
 - Smooth scroll for nav links
 - Mobile nav toggle
 - Scroll reveal via IntersectionObserver
 - Simple contact form handler (uses mailto fallback)
*/

document.addEventListener('DOMContentLoaded', () => {
    // set footer year
    document.getElementById('year').textContent = new Date().getFullYear();

    // Mobile nav toggle
    const navToggle = document.getElementById('nav-toggle');
    const nav = document.getElementById('nav');
    navToggle.addEventListener('click', () => {
        nav.classList.toggle('open');
        navToggle.classList.toggle('open');
    });

    // Smooth scroll for internal links (uses native behavior with fallback)
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', (e) => {
            // close mobile nav if open
            if (nav.classList.contains('open')) nav.classList.remove('open');

            const targetId = a.getAttribute('href').slice(1);
            const target = document.getElementById(targetId);
            if (!target) return;
            e.preventDefault();
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    });

    // IntersectionObserver reveal
    const reveals = document.querySelectorAll('.reveal');
    const io = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                obs.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.12
    });
    reveals.forEach(r => io.observe(r));

    // Contact form: simple client-side handler that opens mailto if server not connected
    const form = document.getElementById('contact-form');
    const formMsg = document.getElementById('form-msg');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const data = new FormData(form);
        const name = data.get('name').trim();
        const email = data.get('email').trim();
        const message = data.get('message').trim();
        if (!name || !email || !message) {
            formMsg.textContent = 'Please fill all fields.';
            return;
        }
        // try sending via a real endpoint here. For now, open user's email client:
        const subject = encodeURIComponent(`Portfolio message from ${name}`);
        const body = encodeURIComponent(message + '\n\n' + 'Contact Email: ' + email);
        window.location.href = `mailto:you@example.com?subject=${subject}&body=${body}`;
        formMsg.textContent = 'Your email client should open. If not, contact directly at you@example.com';
    });

    // keyboard accessibility: close nav on ESC
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && nav.classList.contains('open')) {
            nav.classList.remove('open');
        }
    });
});