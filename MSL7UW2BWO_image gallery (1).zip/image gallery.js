// scripts.js - gallery logic: filtering, lightbox, next/prev, keyboard support
document.addEventListener('DOMContentLoaded', () => {
    const gallery = document.getElementById('gallery');
    const items = Array.from(gallery.querySelectorAll('.item'));
    const catButtons = Array.from(document.querySelectorAll('.cat-btn'));
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    // Lightbox elements
    const lightbox = document.getElementById('lightbox');
    const lbImage = document.getElementById('lbImage');
    const lbCaption = document.getElementById('lbCaption');
    const lbClose = document.getElementById('lbClose');
    const lbPrev = document.getElementById('lbPrev');
    const lbNext = document.getElementById('lbNext');

    // Build an index map of visible items (used for next/prev)
    function visibleItems() {
        return items.filter(it => it.offsetParent !== null && !it.classList.contains('hidden'));
    }

    // Filtering logic (by data-category)
    function filterBy(category) {
        items.forEach(it => {
            if (category === 'all' || it.dataset.category === category) {
                it.classList.remove('hidden');
                it.style.display = ''; // restore
            } else {
                it.classList.add('hidden');
                it.style.display = 'none';
            }
        });
    }

    // Category buttons
    catButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            catButtons.forEach(b => {
                b.classList.remove('active');
                b.setAttribute('aria-selected', 'false');
            });
            btn.classList.add('active');
            btn.setAttribute('aria-selected', 'true');
            const cat = btn.dataset.cat;
            filterBy(cat);
            // Move focus to first visible for convenience
            const first = visibleItems()[0];
            if (first) first.focus();
        });
    });

    // Lightbox open
    function openLightbox(index) {
        const it = items[index];
        if (!it) return;
        const img = it.querySelector('img');
        lbImage.src = img.src;
        lbImage.alt = img.alt || '';
        lbCaption.textContent = it.querySelector('figcaption')?.textContent || '';
        lightbox.classList.add('open');
        lightbox.setAttribute('aria-hidden', 'false');
        currentIndex = index;
        // trap focus on close button quickly
        lbClose.focus();
    }

    // Lightbox close
    function closeLightbox() {
        lightbox.classList.remove('open');
        lightbox.setAttribute('aria-hidden', 'true');
        lbImage.src = '';
        // return focus to the thumbnail if available
        const it = items[currentIndex];
        if (it) it.focus();
    }

    // Next / Prev inside visible items
    function showNext() {
        const vis = visibleItems();
        if (!vis.length) return;
        const curVisibleIndex = vis.indexOf(items[currentIndex]);
        // if current item is hidden (e.g., after filter) use closest
        let nextVisibleIndex = (curVisibleIndex + 1) % vis.length;
        if (curVisibleIndex === -1) {
            // try to find any visible item with same data-index
            nextVisibleIndex = 0;
        }
        const nextItem = vis[nextVisibleIndex];
        openLightbox(items.indexOf(nextItem));
    }

    function showPrev() {
        const vis = visibleItems();
        if (!vis.length) return;
        const curVisibleIndex = vis.indexOf(items[currentIndex]);
        let prevVisibleIndex = (curVisibleIndex - 1 + vis.length) % vis.length;
        if (curVisibleIndex === -1) prevVisibleIndex = vis.length - 1;
        const prevItem = vis[prevVisibleIndex];
        openLightbox(items.indexOf(prevItem));
    }

    // Click on thumbnails to open lightbox
    items.forEach((it, idx) => {
        it.addEventListener('click', () => openLightbox(idx));
        it.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openLightbox(idx);
            }
        });
    });

    // top-level next/prev buttons cycle through visible thumbnails (opens lightbox on the result)
    nextBtn.addEventListener('click', () => {
        // if lightbox open, move inside lightbox; else open next thumbnail
        if (lightbox.classList.contains('open')) {
            showNext();
        } else {
            // open next visible item relative to last focused or 0
            const vis = visibleItems();
            if (!vis.length) return;
            // find currently focused item, else open first
            const focused = document.activeElement;
            const curIdx = vis.indexOf(focused.closest ? focused.closest('.item') : null);
            const nextIdx = curIdx >= 0 ? (curIdx + 1) % vis.length : 0;
            openLightbox(items.indexOf(vis[nextIdx]));
        }
    });
    prevBtn.addEventListener('click', () => {
        if (lightbox.classList.contains('open')) {
            showPrev();
        } else {
            const vis = visibleItems();
            if (!vis.length) return;
            const focused = document.activeElement;
            const curIdx = vis.indexOf(focused.closest ? focused.closest('.item') : null);
            const prevIdx = curIdx >= 0 ? (curIdx - 1 + vis.length) % vis.length : 0;
            openLightbox(items.indexOf(vis[prevIdx]));
        }
    });

    // Lightbox close and nav buttons
    lbClose.addEventListener('click', closeLightbox);
    lbNext.addEventListener('click', showNext);
    lbPrev.addEventListener('click', showPrev);

    // Close when clicking outside image
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) closeLightbox();
    });

    // Keyboard support
    let currentIndex = 0;
    document.addEventListener('keydown', (e) => {
        if (lightbox.classList.contains('open')) {
            if (e.key === 'ArrowRight') {
                showNext();
            } else if (e.key === 'ArrowLeft') {
                showPrev();
            } else if (e.key === 'Escape') {
                closeLightbox();
            }
        } else {
            // when not in lightbox, allow left/right to navigate focus between thumbnails
            if (e.key === 'ArrowRight') {
                const focused = document.activeElement;
                if (focused && focused.classList.contains('item')) {
                    const next = focused.nextElementSibling || gallery.firstElementChild;
                    if (next) next.focus();
                }
            } else if (e.key === 'ArrowLeft') {
                const focused = document.activeElement;
                if (focused && focused.classList.contains('item')) {
                    const prev = focused.previousElementSibling || gallery.lastElementChild;
                    if (prev) prev.focus();
                }
            }
        }
    });

    // Optional: image filters toggle (example: grayscale inactive style)
    // Double-click a category to toggle a subtle grayscale (demonstration)
    catButtons.forEach(btn => {
        btn.addEventListener('dblclick', () => {
            // toggle a class on gallery
            gallery.classList.toggle('filter-grayscale');
        });
    });

    // Initial: show all
    filterBy('all');

    // Accessibility: ensure first item has tabindex 0, others -1 (we used tabindex=0 on all for simplicity)
    // You may refine focus management here if desired.
});