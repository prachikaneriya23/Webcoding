const display = document.getElementById('display');
const buttons = document.querySelectorAll('button');
let currentInput = '';

buttons.forEach(btn => {
    btn.addEventListener('click', () => handleInput(btn.innerText));
});

function handleInput(value) {
    if (value === 'C') {
        currentInput = '';
    } else if (value === '=') {
        try {
            const expression = currentInput
                .replace(/÷/g, '/')
                .replace(/×/g, '*')
                .replace(/−/g, '-');
            currentInput = eval(expression).toString();
        } catch {
            currentInput = 'Error';
        }
    } else {
        currentInput += value;
    }
    display.value = currentInput;
}

// Keyboard support
window.addEventListener('keydown', (e) => {
    if ((e.key >= '0' && e.key <= '9') || ['+', '-', '*', '/', '.'].includes(e.key)) {
        currentInput += e.key;
    } else if (e.key === 'Enter') {
        try {
            currentInput = eval(currentInput).toString();
        } catch {
            currentInput = 'Error';
        }
    } else if (e.key === 'Backspace') {
        currentInput = currentInput.slice(0, -1);
    } else if (e.key.toLowerCase() === 'c') {
        currentInput = '';
    }
    display.value = currentInput;
});